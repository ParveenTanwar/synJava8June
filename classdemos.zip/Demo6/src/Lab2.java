import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Lab2 {

	public static void main(String[] args) {
		List<Emp> list = Data.list(13);
		System.out.println("-----------Original Data -------------------");
		list.stream().forEach(System.out::println);

	     Collector<Emp, ?, Double> summingSalaries
	         = Collectors.summingDouble(Emp::getSalary);

	     Collector<Emp , ?, Map<String, Double>> summingSalariesByProject
	         = Collectors.groupingBy(Emp::getProject, summingSalaries);
	  
	     Map<String, Double> map = list.stream().collect(summingSalariesByProject);
	     System.out.println(map);
	     
	}

}
