import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Lab1 {

	public static void main(String[] args) {
		List<Emp> list = Data.list(13);
		
		List<Emp> filtered = list.stream().filter(e->e.getEname().equals("Mahi")).collect(Collectors.toList());
		
		filtered.forEach(System.out::println);
		System.out.println("-----------Original Data -------------------");
		list.stream().forEach(System.out::println);
		long st = System.currentTimeMillis();
		Map<String, List<Emp>> empbyproject = 
					list.stream().collect(Collectors.groupingBy(Emp::getProject));
					//list.stream().collect(Collectors.groupingBy(e->e.getProject()));
		long et = System.currentTimeMillis();
		System.out.println("Total Time taken = " + (et-st));
		
		System.out.println("-----------------Employees Mapped by Project ---------------");
		
		System.out.println(empbyproject.get("proj1"));
	}

}
