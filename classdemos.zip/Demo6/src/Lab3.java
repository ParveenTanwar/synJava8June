import java.util.List;
import java.util.stream.Collectors;

public class Lab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Emp> list = Data.list(9999000);
		long st = System.currentTimeMillis();
		// Serial processing
		List<Emp> filtered = list.stream().filter(e->e.getEname().equals("Mahi")).collect(Collectors.toList());
		// Parallel Processing
		//List<Emp> filtered = list.parallelStream().filter(e->e.getEname().equals("Mahi")).collect(Collectors.toList());
		long et = System.currentTimeMillis();

	    filtered.forEach(e-> System.out.println(".."+e));
		System.out.println("Total Time taken = " + (et-st));
	}

}
