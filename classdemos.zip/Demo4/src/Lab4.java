import java.io.FileReader;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Lab4 {
	public static void main(String[] args) throws Exception {
		ScriptEngineManager factory = new ScriptEngineManager();
		ScriptEngine engine = factory.getEngineByName("nashorn");
		try {
			engine.eval("print('Hello, World!');");
			engine.eval("function sum(a, b) { return a + b; }");
			System.out.println(engine.eval("sum(1, 20);"));

			engine.eval(new FileReader("src/hw.js"));
			// System.out.println(engine.eval(""));

		} catch (final ScriptException se) {
			se.printStackTrace();
		}
	}
}
