package old;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DeptDAO {
 private List<Dept> list = new ArrayList<Dept>();
			public void create(Dept d) {
				System.out.println("Create form DeptDAO invoked with..." + d );
				list.add(d);
			}
			public List<Dept> read(){
				return list;
			}
			public void 	update(Dept newdept){
				for (Dept dept : list) {
					if (dept.getDeptno() == newdept.getDeptno()) {
						dept.setDname(newdept.getDname());
						dept.setLoc(newdept.getLoc());
						break;
					}
				}
			}
			
			public void delete(int deptno){
				for (Dept dept : list) {
					if (dept.getDeptno() == deptno) {
						list.remove(dept);
						break;
					}
			}
			}
			public static void main(String[] args) {
				DeptDAO dao = new DeptDAO();
				for(int i = 10;i<=100;i+=10) {
					if ((i%20)==0) 
						dao.create(new Dept(i,"Dnameof"+i, "Hyd"));
					else
						dao.create(new Dept(i,"Dnameof"+i, "Blr"));
				}
				dao.delete(20);
				dao.update(new Dept(10,"HR", "Pnq"));
		//		dao.list.forEach((d)->System.out.println(d));
				for (Dept dept : dao.list) {
					System.out.println(dept);
				}
			}
		}

