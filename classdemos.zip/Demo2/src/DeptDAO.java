import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


public class DeptDAO implements Dao<Dept,Integer> {
 private List<Dept> list = new ArrayList<Dept>();

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Press a number to continue");
		Scanner scan = new Scanner(System.in);
				scan.nextInt();
		DeptDAO dao = new DeptDAO();
		for(int i = 10;i<=99999000;i+=10) {
			if ((i%20)==0) 
				dao.create(new Dept(i,"Dnameof"+i, "Hyd"));
			else
				dao.create(new Dept(i,"Dnameof"+i, "Blr"));
			Thread.sleep(1);
		}
/*		DeleteCheck<Integer> check = (x,y)->x==y;
		dao.delete(check, 20);*/
		//dao.delete((d)->d.getDeptno()==20);
		dao.update(new Dept(10,"HR", "Pnq"));
	   dao.delete((d)->d.getLoc().equalsIgnoreCase("HYD"));
	//	dao.delete((d)->true);
		dao.list.forEach(d->System.out.println(d));
	/*	for (Dept dept : dao.list) {
			System.out.println(dept);
		}
	*/
	}
	@Override
	public List<Dept> getList() {
		// TODO Auto-generated method stub
		return list;
	}

	public void 	update(Dept newdept){
		for (Dept dept : list) {
			if (dept.getDeptno() == newdept.getDeptno()) {
				dept.setDname(newdept.getDname());
				dept.setLoc(newdept.getLoc());
				break;
			}
		}
	}
}

	
	/*
 * Option 1 - limited scope for deleting with primary key
public interface DeleteCheck<T> {
	boolean delete(T deptdeptno, T deptno);
}

	@Override
	public void delete(DeleteCheck<Integer> check, Integer deptno) {
		for (Dept dept : list) {
			if (check.delete(dept.getDeptno(), deptno)) {
				System.out.println("Deleteing ..." + deptno);
				list.remove(dept);
				break;
			}
		}
	}
*/