import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class EmpDAO implements Dao<Emp,Integer> {
 private List<Emp> list = new ArrayList<Emp>();

	public static void main(String[] args) {
		EmpDAO dao = new EmpDAO();
		for(int i = 1;i<=10;i+=1) {
		dao.create(new Emp(i,"nameof"+i, i*100));
		}
		dao.update(new Emp(1,"One",111 ));
		dao.delete((e)->e.getSalary() >= 800);
		
		for (Emp emp : dao.list) {
			System.out.println(emp);
		}
		}
	@Override
	public List<Emp> getList() {
		// TODO Auto-generated method stub
		return list;
	}

	public void 	update(Emp newemp){
		for (Emp emp : list) {
			if (emp.getEmpno() == newemp.getEmpno()) {
				emp.setEname(newemp.getEname());
				emp.setSalary(newemp.getSalary());
				break;
			}
		}
	}
}

