import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Lab1 {
public static void main(String[] args) {
	Stream<Integer> strint = Stream.of(10,50,31,55,7,44);
	strint.forEach(System.out::println);
//	strint.forEach(System.out::println); error

	List<String> projects = Arrays.asList("proj1","proj2","proj3");
	System.out.println();
	projects.stream().forEach( System.out::println);
	System.out.println();
	projects.stream().forEach( System.out::println);
	System.out.println();
	projects.stream().forEach( System.out::println);
	
//   Stream str =projects.stream() ;
//	str.forEach( System.out::println);
//	str.forEach( System.out::println);
}
}
