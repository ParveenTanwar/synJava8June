import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Lab3 {
	public static void main(String[] args) {

		List<Emp> empList = Data.list(50);
/*
		empList.forEach(System.out::println);
		empList.stream().filter(e -> e.getProject().equals("proj2") && e.getEname().equals("Sonali"))
				.forEach(System.out::println);
		System.out.println("\n\n");
		// or
*/
		/*empList.stream().filter(e -> e.getProject().equals("proj2"))
				.peek(e -> System.out.println("After first filter" + e)).filter(e -> e.getEname().equals("Sonali"))
				.forEach(e -> System.out.println("After second filter" + e));
				
				*/
		Optional<Emp> optemp = empList.stream().filter(e -> e.getProject().equals("proj2"))
		.peek(e -> System.out.println("After first filter" + e)).filter(e -> e.getEname().equals("Sonali"))
		.findFirst();
		if (optemp.isPresent())
			System.out.println("Emp returned "+ optemp);
			
	}

}
