import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Data {

	public static List<Emp> list(int no ){
		List<String> projects = Arrays.asList("proj1","proj2","proj3");
		List<String> names = Arrays.asList("Vaishali","Sonali","Saloni","Vishal","Zarin","Mahesh","Mahi");
		
		
		List<Emp> list = new ArrayList<Emp>();
		for (int i = 1;i<=no;i++) {
			Emp e = new Emp();
			e.setEmpno(i);
			e.setEname(names.get(i%7));
			e.setProject(projects.get(i%3));
			e.setSalary(i *(int)( Math.random()*1000));
			list.add(e);
		}
		return list;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Data.list(10).forEach(System.out::println);
	}

}
