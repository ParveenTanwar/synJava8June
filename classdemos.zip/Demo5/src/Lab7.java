import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stream<Integer> strint = Stream.of(10,50,3,4,2,1);
		List<String> names = Arrays.asList("Vaishali","Sonali","Saloni","Vishal","Zarin","Mahesh","Mahi");
		
		Integer i = strint.reduce(0,(a,b)->a+b);
		System.out.println("Sum = " + i);
		String str= names.stream().reduce("_",(a,b)->a+b);
		System.out.println("Names Reduce = " + str);

		strint = Stream.of(4,2,2);


		i = strint.reduce(1,(a,b)->a*b);
		System.out.println("Multiplication = " + i);
	
		
		
	}
	

}
