import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> names = Arrays.asList("Vaishali","Sonali","Saloni","Vishal","Zarin","Mahesh","Mahi");
		names.stream().map(s->s.length()).forEach(System.out::println);
		int max =names.stream().mapToInt(s->s.length()).max().getAsInt();
		System.out.println("max = " + max);

		int[] arr =  {10,50,31,5};
		int[] arr1 =  {11,22};
		Stream.of(arr,arr1).forEach(e->System.out.println(Arrays.toString(e)));
		System.out.println("-----------------Print Length--------------------");
		Stream.of(arr,arr1).map(ar->ar.length).forEach(System.out::println);
		System.out.println("-----------Output of Flat Map");
		Stream.of(arr,arr1).flatMapToInt(ar->IntStream.of(ar)).forEach(System.out::println);
	
		List<String> l1 = Arrays.asList("Vaishali","Sonali");
		List<String> l2 = Arrays.asList("one","two","three");
		List<String> l3 = Arrays.asList("11","22","33","44");
		List<List<String>> hlist = new ArrayList<List<String>>();
		hlist.add(l1);hlist.add(l2);hlist.add(l3);
		System.out.println("Count = " + hlist.stream().count());
		System.out.println("------------Map to size-------------" );
		hlist.stream().map(lst->lst.size()).forEach(System.out::println);
		System.out.println("------------Flat Map - count-------------" );
		System.out.println("Count = " +hlist.stream().flatMap(ls1->ls1.stream()).count());
		
	}

}
