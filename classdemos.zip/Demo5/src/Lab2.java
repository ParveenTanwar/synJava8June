import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Lab2 {
public static void main(String[] args) {
	Stream<Integer> strint = Stream.of(10,50,31,55,7,44);
	List<String> names = Arrays.asList("Vaishali","Sonali","Saloni","Vishal","Zarin","Mahesh","Mahi");
	
	System.out.println();
	Stream<Integer> str1=Stream.of(10,20,30,40,50);
	str1.filter(s->s>20 && s<50).forEach(System.out::println);
	
	names.stream().filter(e->e.startsWith("V")).forEach(System.out::println);
	System.out.println();
	names.stream().filter(e->e.endsWith("i")).forEach(System.out::println);
	
	System.out.println();
	names.stream().filter(e->e.contains("s")).forEach(System.out::println);
	System.out.println();
	names.stream().filter(e->e.length()>5).forEach(System.out::println);

	List<Emp> empList = Data.list(10);
	
	empList.stream().filter(e->e.getEname().equals("Saloni")).forEach(System.out::println);
	System.out.println();
	empList.stream().filter(e->e.getSalary()>1000 && e.getSalary()<2000).forEach(System.out::println);
		System.out.println();
	empList.stream().filter(e->e.getProject().equals("proj1") || e.getProject().equals("proj2")).forEach(System.out::println);	
}


}

