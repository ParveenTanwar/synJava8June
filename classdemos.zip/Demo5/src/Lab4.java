import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Lab4 {
	public static void main(String[] args) {

		List<Emp> empList = Data.list(50);
		empList.stream().limit(5).forEach(System.out::println);
		System.out.println("\n\n");
		empList.stream().skip(10).limit(5).forEach(System.out::println);
	}

}
