import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.PrimitiveIterator.OfDouble;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab5 {
	public static void main(String[] args) {
		int[] arr =  {10,50,31,55,7,44, 55};
		int[] arr1 =  {11,22,33};
		System.out.println("Count = " + Stream.of(arr,arr1).count());
		System.out.println("Count = " + IntStream.of(arr).count());
		
		System.out.println("Min = " +  	IntStream.of(arr).min().getAsInt());
		System.out.println("Max = " +  	IntStream.of(arr).max().getAsInt());
		System.out.println("Distinct..");
		IntStream.of(arr).distinct().forEach(System.out::println);
		System.out.println("\n\nSorting....");
		IntStream.of(arr).sorted().forEach(System.out::println);
		
		List<Emp> empList = Data.list(10);
		System.out.println("-------------- Emp List -------------");
		empList.forEach(System.out::println);
		System.out.println("-------------- Emp List -------------");
		System.out.println("Count = " + empList.stream().count());
		Comparator<Emp> comp = (e1,e2)->Double.compare(e1.getSalary(),e2.getSalary());
		System.out.println("Min Salary = " + empList.stream().min(comp));
		System.out.println("Max Salary = " + empList.stream().max(comp));
				
	}

}
