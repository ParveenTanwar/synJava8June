import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;

public class Lab2 {
	public static void main(String[] args) {

		// skip () for single argument
		Consumer<Emp> print = e -> System.out.println(e);
		print.accept(new Emp(1, "Enameof", 1000));

		List<Integer> list = Arrays.asList(10, 40, 600, 60);
		// single line vs multi line
		// list.forEach(e-> System.out.println(e));
		// value is local variable for that lambda function
		list.forEach(e -> {
			int value = 10;
			value += e;
			System.out.println(value);
		});

		BinaryOperator<String> concat = (i, j) -> i + j;
		System.out.println("Concat = " + concat.apply("A", "B"));
		 concat = (i,j)->{ return i+j; };
		 System.out.println("Concat = " + concat.apply("Ab", "Cd"));
	}
}
