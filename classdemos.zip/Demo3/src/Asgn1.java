import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class Asgn1 {
	
	public static void main(String args[])
	{
		List<Emp> listEmp= new ArrayList<Emp>();
		
		Consumer<Emp> create=(e)->{
			System.out.println("Create ..." + e );
			listEmp.add(e);
		};
		
		for(int i = 1;i<=10;i+=1) {
			create.accept(new Emp(i,"Enameof"+i, i*1000));
		}
		listEmp.forEach(System.out::println);
		
		// 1. modify all employees to have  salary = 1000
	/*	
		 // listEmp.forEach((e)->e.setSalary(1000));
				
		listEmp.replaceAll(e ->{
			e.setSalary(1000) ;
			return e;
		});
		System.out.println("After salary =1000");
		listEmp.forEach(System.out::println);
	*/	
		//2. modify employees where salary > 2000, salary += 20% of salary
		
		/*
		 * listEmp.forEach((e)-> { if(e.getSalary()>2000)
		 * e.setSalary(e.getSalary()+.2*e.getSalary()); });
		 */
	
		listEmp.replaceAll(e ->{
			if (e.getSalary()>2000)
				e.setSalary(e.getSalary()+.2*e.getSalary());
			return e;
		});
		
		System.out.println("after setting salary 20%");
		listEmp.forEach((e)->System.out.println(e));
		
		
		//3. Filter (Predicate)
		System.out.println("Records where salary > 6000");
		Predicate<Emp> filterEmp=(e)->e.getSalary()>6000;
		listEmp.forEach(e1-> {
			if(filterEmp.test(e1))
				System.out.println(e1);
		});
	}
}
