@FunctionalInterface
interface MyIntBinaryTest{
			public int op(int x, int y);
}
@FunctionalInterface
interface Calc1{
	public int process(MyIntBinaryTest test);
}
public class Asgn1 {

	public static void main(String[] args) {
		MyIntBinaryTest add = (a,b)->a+b;
		MyIntBinaryTest sub = (a,b)->a-b;
		MyIntBinaryTest mult = (a,b)->a*b;
		MyIntBinaryTest div = (a,b)->a/b;
		
		System.out.println("Add for 10,2  returned " + add.op(10, 2));
		System.out.println("Sub for 10,2  returned " + sub.op(10, 2));
		System.out.println("Mult for 10,2  returned " + mult.op(10, 2));
		System.out.println("Div for 10,2  returned " + div.op(10, 2));
		
		Calc1 calc1 = (test)->{
				System.out.println("In Calc1 Impl");
				int i = test.op(10, 20);
				System.out.println("Ouput = " + i );
				return i;
		};
		calc1.process(add);
		calc1.process(sub);
	}

}
