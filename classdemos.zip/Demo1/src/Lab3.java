interface Test{
	void method1();
	default void method2() {
		System.out.println("Test - method2 - default implementation in Test Interface");
	}
}
class TestImpl1 implements Test{
	@Override
	public void method1() {
			System.out.println("Test - method1 - implemented in TestImpl1");
	}
}
class TestImpl2 implements Test{
	@Override
	public void method1() {
			System.out.println("Test - method1 - implemented in TestImpl2");
	}
	public void method2() {
		System.out.println("Test - method2 - implementation in  TestImpl2 class");
	}
}

public class Lab3 {
public static void main(String[] args) {
	Test impl1 = new TestImpl1();
	impl1.method1();
	impl1.method2();
	Test impl2 = new TestImpl2();
	impl2.method1();
	impl2.method2();
}
}

