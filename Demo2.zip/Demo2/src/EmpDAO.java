import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EmpDAO {
 private List<Emp> list = new ArrayList<Emp>();
			public void create(Emp d) {
				System.out.println("Create form EmpDAO invoked with..." + d );
				list.add(d);
			}
			public List<Emp> read(){
				return list;
			}
			public void 	update(Emp newEmp){
				for (Emp emp : list) {
					if (emp.getEmpno() == newEmp.getEmpno()) {
						emp.setEname(newEmp.getEname());
						emp.setSalary(newEmp.getSalary());
						break;
					}
				}
			}
			
			public void delete(int Empno){
				for (Emp Emp : list) {
					if (Emp.getEmpno() == Empno) {
						list.remove(Emp);
						break;
					}
			}
			}
			public static void main(String[] args) {
				EmpDAO dao = new EmpDAO();
				for(int i = 1;i<=10;i+=1) {
						dao.create(new Emp(i,"Enameof"+i, i*1000));
						}
				dao.delete(2);
				dao.update(new Emp(1,"Vaishali", 111));
		//		dao.list.forEach((d)->System.out.println(d));
				for (Emp emp : dao.list) {
					System.out.println(emp);
				}
			}
		}

