// Rule 1 - Only one method (abstract) -> Single Abstract Method (SAM)


@FunctionalInterface
interface Calc {
	public int add(int i, int j);	
}
/*class CalcImpl implements Calc
{
	@Override
	public int add(int i, int j) {	
		return i+j;
	}
}*/

public class Lab2 {
	public static void main(String[] args) {
		//Calc c= new CalcImpl();
	/*	Calc c =  (int i, int j) -> {	
			return i+j;
		};*/
		Calc c = (x,y)->x+y;
		System.out.println("Sum = " + c.add(10,40));	
	}
	 
}
