//	Write DeptDAO implements Connection , Transaction
interface Connection {
	default void open() {
		System.out.println("Open from Connection Interface");
	}
	void close();
}	
interface Transaction {
	void open();
	void commit();
}
class DeptDAO implements Connection, Transaction{

	@Override
	public void commit() {
		// TODO Auto-generated method stub
		System.out.println("Commit in DeptDAO for Transaction");
	}
	@Override
	public void open() {
		System.out.println("Open in DeptDAO for Connection as well as Transaction");
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println("Close in DeptDAO for Connection");
	}
	
}
public class Lab5 {
	public static void main(String[] args) {
		DeptDAO dao = new DeptDAO();
		dao.open();
		dao.commit();
		dao.close();
		
		Connection con = dao;
		con.open();
		con.close();
		
		Transaction tr = dao;
		tr.open();
		tr.commit();
		
	}
	
}
