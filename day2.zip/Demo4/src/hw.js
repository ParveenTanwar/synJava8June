print("Hello Nashorn!");
