import java.util.Arrays;
import java.util.List;
import java.util.Optional;
class Lab3Helper {
	private List<String> l1 =  Arrays.asList("Vaishali","Simran", "Vasanti");
	
/*	public Optional<Integer> find(String str) //throws Exception
	{
		for (int i = 0; i < l1.size(); i++) {
			if (l1.get(i).equals(str))
				return Optional.of(i);
		}
		return Optional.empty();
	}

*/
	public Optional<Integer> find(String str) //throws Exception
	{
		Integer num1 = null;
	
		for (int i = 0; i < l1.size(); i++) {
			if (l1.get(i).equals(str)) {
				num1 = i;
				break;
			}
		}
		return Optional.ofNullable(num1);
	}
}	

public class Lab3 {
public static void main(String[] args) {
		Lab3Helper helper = new Lab3Helper();
		Optional<Integer> optionalno = helper.find("Vaanti");
		if (optionalno.isPresent())
			System.out.println("Record Found ....and position = " + optionalno.get());
		else
			System.out.println("Record Not Found ....");

}
}
