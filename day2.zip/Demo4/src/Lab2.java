import java.time.LocalDate;
import java.util.Date;

public class Lab2 {
public static void main(String[] args) {
	LocalDate date = LocalDate.of(2021, 06, 1);
	System.out.println(date);
}
}
