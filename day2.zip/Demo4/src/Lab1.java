import java.util.Date;

public class Lab1 {
public static void main(String[] args) {
	System.out.println("Current Date = " + new Date());
	System.out.println("Current Date = " + new java.sql.Date(new Date().getTime()));
}
}
