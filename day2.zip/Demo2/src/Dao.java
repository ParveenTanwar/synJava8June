import java.util.List;
import java.util.function.Predicate;
// First T- pojo, t1 - pk type of pojo
public interface Dao<T, T1> {
	public default void create(T t) {
		System.out.println("DAO Interface - Create " + t);
		getList().add(t);
	}
	public List<T> getList();
//	public void delete(DeleteCheck<T1> check, T1 deptno);
	public default void delete(Predicate<T> pred) {
		System.out.println("in delete of DAO with " + pred);
		getList().removeIf(pred);
	}
	public void update(T newtype);
}
