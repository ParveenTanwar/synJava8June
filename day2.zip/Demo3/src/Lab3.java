import java.util.Arrays;
import java.util.List;

public class Lab3 {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(10, 40, 600, 60);
		int value1 = 100;
		list.forEach(e -> {
		//	System.out.println("Value = " + value1);
			e = e+value1;
			System.out.println(e);
		});
	
		System.out.println(" Static call to println");
		list.forEach(System.out::println);
	}
}
