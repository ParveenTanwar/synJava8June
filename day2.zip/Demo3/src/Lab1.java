import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.DoubleSupplier;
import java.util.function.DoubleUnaryOperator;
import java.util.function.Function;
import java.util.function.IntBinaryOperator;
import java.util.function.IntSupplier;
import java.util.function.IntUnaryOperator;
import java.util.function.Predicate;

public class Lab1 {
	public static void main(String[] args) {
		//1. int sqr(int)
		IntUnaryOperator sqr = (i)->i*i;
		System.out.println(sqr.applyAsInt(5));
		
		//2. double sqr(double)
		DoubleUnaryOperator doub=(i)->i*i;
		System.out.println(doub.applyAsDouble(1.2));
		//3. int add(int , int)
		IntBinaryOperator binadd=(i,j)->i+j;
		System.out.println(binadd.applyAsInt(5, 5));
		//4. double divide(String, String)
		BiFunction< String, String,Double> binfun=(i,j)->((double)(Integer.parseInt(i))/Integer.parseInt(j));
		System.out.println(binfun.apply("8", "3"));
		//6. int random()
		DoubleSupplier supp=()->Math.random();
		System.out.println(supp.getAsDouble());
		//7. double getSalary(Emp)
		Function<Emp, Double> salary=(e)->e.getSalary();
		System.out.println(salary.apply(new Emp(1,"Enameof", 1000)));
		//8. String concat(String, String)
		BinaryOperator<String> concat=(i,j)->i+j;
		System.out.println(concat.apply("a", "b"));
		//9. void process(Emp e) -> insert a record in table
		Consumer<Emp> print = (e)->System.out.println(e);
		print.accept(new Emp(1,"Enameof", 1000));
		//10. bool checkOdd(int)
		  Predicate<Integer> pred = (a) -> a%2==0;
		  System.out.println(pred.test(3));

			
	}
	 
}
