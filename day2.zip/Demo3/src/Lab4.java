import java.util.Arrays;
import java.util.List;
public class Lab4 {
	public static void print(List<Integer> list, int value1) 
	{
	//	value1 = 2000;
		System.out.println(value1);
		list.forEach((e) -> {
		//	System.out.println("Value = " + value1);
			e = e+value1;
			System.out.println(e);
		});
	}

	
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(10, 40, 600, 60);
		int value1 = 100;
		print(list, value1);
		value1 = 200;
		System.out.println(value1);
	}
}
