/*class Lab1Helper implements Runnable
{
	public void run() {
		System.out.println("Hello from Lab1Helper - Runnable Implentation");
	}
}*/
public class Lab1 {

	public static void main(String[] args) {
	//	Runnable r = new Lab1Helper();
/*		Runnable r = () -> {
			
		};
*/
		Runnable r = ()->System.out.println("Hello from Lab1Helper-single - Runnable Implentation"); 
		Thread th = new Thread(r);
		th.start();
	}
}
