interface Check{
	void method1();
    static void method2() {
		System.out.println("Test - method2 - static implementation in Test Interface");
	}
}
class CheckImpl1 implements Check{
	@Override
	public void method1() {
		System.out.println("start of Method1 - CheckImpl1");
		Check.method2();
		System.out.println("end of Method1 - CheckImpl1");
		
	}
	public void method2() {
		System.out.println("Method2 - CheckImpl1");
	}
}

public class Lab4 {
public static void main(String[] args) {
	CheckImpl1 impl1 = new CheckImpl1();
	Check check1 =impl1;
	check1.method1();
	Check.method2();
	impl1.method2();
	
}
}

